import test from 'node:test';
import assert from 'node:assert/strict';
import { validateFeedback } from '../lib/evidence/feedback.ts';
const valid={id:'6c448f1d-bd54-4034-999f-9201be109f68',helpful:1,mode:'fusion',status:'evidence'};
test('feedback accepts only rating metadata',()=>assert.deepEqual(validateFeedback(valid),valid));
test('private text, invalid ratings and identifiers are rejected',()=>{for(const v of [{...valid,question:'private'},{...valid,helpful:2},{...valid,id:'bad'},{...valid,mode:'other'},{...valid,status:'other'},[],null])assert.throws(()=>validateFeedback(v));});
import { parseFeedbackSummary, readFeedbackBody } from '../lib/evidence/feedback.ts';
test('summary rejects impossible counts',()=>{assert.deepEqual(parseFeedbackSummary({total:3,helpful:2}),{total:3,helpful:2});for(const v of [{total:1,helpful:2},{total:-1,helpful:0},{total:1.5,helpful:1},{}])assert.throws(()=>parseFeedbackSummary(v));});
test('feedback body limit applies even without a content-length header',async()=>{assert.equal(await readFeedbackBody(new Request('https://test.test',{method:'POST',body:'{}'})),'{}');await assert.rejects(readFeedbackBody(new Request('https://test.test',{method:'POST',body:'a'.repeat(1001)})),/limit/);});
