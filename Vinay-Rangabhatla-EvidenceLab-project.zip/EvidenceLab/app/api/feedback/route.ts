import { getDatabase } from '@/db';
import { validateFeedback, insertFeedbackSql, feedbackSummarySql, readFeedbackBody } from '@/lib/evidence/feedback';
export const dynamic='force-dynamic';
async function summary() {const row=await getDatabase().prepare(feedbackSummarySql).first<{total:number;helpful:number}>();return {total:Number(row?.total??0),helpful:Number(row?.helpful??0)};}
export async function GET() {try{return Response.json(await summary(),{headers:{'Cache-Control':'no-store'}});}catch{console.error('feedback_read_unavailable');return Response.json({error:'Visitor feedback is temporarily unavailable.'},{status:503});}}
export async function POST(request: Request) {
 if (!request.headers.get('content-type')?.includes('application/json')) return Response.json({error:'Expected JSON.'},{status:415});
 const origin=request.headers.get('origin');
 if (origin && origin!==new URL(request.url).origin) return Response.json({error:'Feedback must come from this website.'},{status:403});
 let raw:string;try{raw=await readFeedbackBody(request);}catch{return Response.json({error:'Feedback payload is too large.'},{status:413});}
 let value;try{value=validateFeedback(JSON.parse(raw));}catch{return Response.json({error:'Invalid feedback.'},{status:400});}
 try{await getDatabase().prepare(insertFeedbackSql).bind(value.id,value.helpful,value.mode,value.status,Date.now()).run();return Response.json({saved:true,...await summary()},{headers:{'Cache-Control':'no-store'}});}catch{console.error('feedback_write_unavailable');return Response.json({error:'Feedback could not be saved. Try again.'},{status:503});}
}
