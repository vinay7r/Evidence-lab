import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';
import { answer } from '../../lib/evidence/engine.ts';
import { projectDocuments } from '../../lib/evidence/dataset.ts';
import { generateAnswer } from '../../lib/evidence/llm.ts';
const args=process.argv.slice(2);const question=args[0];
if (!question || question.startsWith('--')) {console.error('Usage: node scripts/evidence/ask.mjs "question" [--docs path] [--llm]');process.exit(1);}
try {
 let documents=projectDocuments;
 const dirIdx=args.indexOf('--docs');
 if(dirIdx!==-1){const directory=args[dirIdx+1];if(!directory)throw new Error('--docs needs a directory.');const names=(await readdir(directory)).filter(n=>/\.(md|txt)$/i.test(n));if(names.length>20)throw new Error('At most 20 files are allowed.');documents=[];for(const name of names){const bytes=await readFile(join(directory,name));if(bytes.byteLength>200_000)throw new Error(`${name} exceeds 200 KB.`);const text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);if(!text.trim()||text.includes('\0'))throw new Error(`${name} is not plain text.`);documents.push({id:name,title:name,text});}}
 const result=answer(question,documents);
 const generated=args.includes('--llm')?await generateAnswer(result,{apiKey:process.env.OPENAI_API_KEY??'',model:process.env.OPENAI_MODEL??''}):null;
 console.log(JSON.stringify({projectOwner:'Vinay Rangabhatla',retrieval:result,...(generated?{generated}: {})},null,2));
} catch(e){console.error(e.message);process.exit(1);}
