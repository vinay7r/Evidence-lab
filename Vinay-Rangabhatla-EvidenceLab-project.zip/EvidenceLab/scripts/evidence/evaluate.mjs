import { mkdir, writeFile } from 'node:fs/promises';
import { evaluate } from '../../lib/evidence/engine.ts';
import { projectDocuments, evalCases } from '../../lib/evidence/dataset.ts';
const results=['bm25','tfidf','fusion'].map(mode=>({mode,report:evaluate(projectDocuments,evalCases,{mode})}));
await mkdir('docs',{recursive:true});
await writeFile('docs/evaluation-results.json',JSON.stringify({projectOwner:'Vinay Rangabhatla',generatedAt:new Date().toISOString(),dataset:'Actual EvidenceLab technical documentation; development set, not held-out',results},null,2)+'\n');
console.table(results.map(({mode,report})=>({method:mode,recall:report.metrics.recall.toFixed(3),mrr:report.metrics.mrr.toFixed(3),ndcg:report.metrics.ndcg.toFixed(3),refusals:report.metrics.abstentionAccuracy.toFixed(3),decisions:report.metrics.decisionAccuracy.toFixed(3),p95_ms:report.metrics.p95Ms.toFixed(2)})));
