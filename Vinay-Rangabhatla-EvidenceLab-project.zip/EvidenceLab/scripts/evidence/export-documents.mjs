import { mkdir, writeFile } from 'node:fs/promises';
import { projectDocuments } from '../../lib/evidence/dataset.ts';
await mkdir('docs/knowledge',{recursive:true});
for (const doc of projectDocuments) await writeFile(`docs/knowledge/${doc.id}.md`,`# ${doc.title}\n\nProject owner: **Vinay Rangabhatla**\n\n${doc.text}\n`);
console.log(`Exported ${projectDocuments.length} owner-branded project documents.`);
