// The portable source package excludes the live Site identity and all secrets.
import { spawnSync } from 'node:child_process';
const result=spawnSync('python3',['-c',String.raw`
from pathlib import Path
import zipfile,json
root=Path.cwd();out=root/'public/downloads/Vinay-Rangabhatla-EvidenceLab-project.zip';out.parent.mkdir(parents=True,exist_ok=True)
exclude={'node_modules','.git','.sites-runtime','.openai','dist','.next','.wrangler'}
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if any(part in exclude for part in rel.parts) or str(rel).startswith('public/downloads/') or p.name.startswith('.env') or p.name.endswith('.tsbuildinfo'):continue
 files.append((p,rel))
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p,rel in sorted(files):z.write(p,'EvidenceLab/'+str(rel))
 z.writestr('EvidenceLab/.openai/hosting.json',json.dumps({'d1':'DB','r2':None},indent=2)+'\n')
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert all('/node_modules/' not in n and '/.env' not in n for n in z.namelist())
 assert 'project_id' not in z.read('EvidenceLab/.openai/hosting.json').decode()
print(json.dumps({'files':len(files)+1,'archiveBytes':out.stat().st_size,'archive':str(out)}))
`],{stdio:'inherit'});
if(result.error)throw result.error;process.exitCode=result.status??1;
