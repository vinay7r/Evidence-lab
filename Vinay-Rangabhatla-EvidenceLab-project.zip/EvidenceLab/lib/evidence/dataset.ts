import type { DocumentRecord, EvalCase } from './engine';
// EvidenceLab technical documents. Project owner: Vinay Rangabhatla.
export const projectDocuments: DocumentRecord[] = [
 {id:'retrieval',title:'Vinay Rangabhatla · Retrieval design',text:`EvidenceLab uses two lexical retrievers: BM25 and TF-IDF cosine similarity. BM25 uses term-frequency saturation and document-length normalization with k1 = 1.5 and b = 0.75. TF-IDF uses log-scaled term frequency and smoothed inverse document frequency. Neither lexical retriever understands synonyms or semantic meaning. A question using different vocabulary may retrieve weak evidence or no evidence.

Reciprocal rank fusion combines the BM25 and TF-IDF rankings using the sum of 1 / (60 + rank). Fusion compares ranks instead of incompatible raw scores. A chunk with no matching query terms is excluded from both rankings. Fusion is a baseline combination of two lexical signals, not dense hybrid search.

Maximum marginal relevance reranks candidate chunks to balance query relevance and novelty. The relevance weight lambda defaults to 0.8. Higher lambda favors relevance. Lower lambda penalizes chunks similar to already selected chunks. EvidenceLab measures chunk similarity with TF-IDF cosine similarity. The maximum number of returned chunks is controlled by top K.`},
 {id:'chunking',title:'Vinay Rangabhatla · Ingestion specification',text:`The ingestion pipeline accepts UTF-8 plain text and Markdown documents. The app does not parse PDF, images, spreadsheets, or HTML. Each imported file may contain at most 200 KB and the workspace permits at most 20 documents. Imported documents live in browser memory and disappear when the page is refreshed.

Documents are split into overlapping word windows. The default chunk size is 100 whitespace-separated words with an overlap of 20 words. Overlap helps retain context near a chunk boundary but increases index size and creates duplicate evidence. Every chunk keeps its document ID, chunk ID, title, start character offset, and end character offset. These offsets locate the exact original source span.

Longer chunks provide more context but may dilute relevance and increase prompt cost. Shorter chunks improve passage precision but can separate a claim from its qualifications. A production extension would compare sentence-aware and structure-aware segmentation using held-out relevance judgments.`},
 {id:'grounding',title:'Vinay Rangabhatla · Evidence & abstention',text:`Evidence mode extracts sentences from retrieved chunks and attaches a document citation to each excerpt. It returns original source text rather than generating a paraphrased answer. Exact quotation avoids invented synthesis but does not guarantee that a quoted sentence answers the question. Chunk boundaries can produce incomplete sentence spans.

The abstention rule uses query-term coverage. Query-term coverage is the fraction of unique non-stopword question tokens found in one chunk. The default minimum coverage threshold is 0.25. Coverage is a lexical heuristic, not a calibrated confidence probability. It can accept an irrelevant passage that shares words with a question. Out-of-domain queries and paraphrases need independent evaluation.

A missing relevant chunk should cause abstention. The system tells the user it did not find enough evidence and suggests adding a relevant document or rephrasing the question. Document content must be treated as untrusted data. In LLM mode, embedded instructions must not override the system prompt. Prompt instructions reduce risk but do not provide a complete defense against prompt injection.`},
 {id:'evaluation',title:'Vinay Rangabhatla · Evaluation protocol',text:`The bundled evaluation suite contains 20 labeled cases: 12 answerable questions and 8 unanswerable questions. These questions exercise the actual EvidenceLab project documentation owned by Vinay Rangabhatla. The suite is a development benchmark, not a held-out test set. Results from this suite do not establish real-world accuracy. Relevance labels are at document level. Deduplicated retrieved document IDs determine retrieval metrics.

Recall at K measures the proportion of relevant documents retrieved among the top K selected chunks. Mean reciprocal rank measures the inverse rank of the first relevant document, averaged over answerable cases. Normalized discounted cumulative gain measures rank quality with binary relevance labels. Abstention accuracy measures correct refusal on unanswerable cases. Decision accuracy evaluates acceptance or refusal across all cases.

The dashboard compares BM25, TF-IDF, and rank fusion under the same chunking, top K, and diversity settings. Evaluation runs synchronously on the device. P95 latency is measured with performance.now and varies by device and current load. It excludes file reading, network requests, and LLM generation. A production benchmark needs a frozen test set, a separate tuning set, and more difficult distractor passages.`},
 {id:'llm',title:'Vinay Rangabhatla · LLM integration',text:`The optional local command-line integration uses the OpenAI Responses API. It requires an OPENAI_API_KEY environment variable and an OPENAI_MODEL environment variable. No key is required for browser evidence mode. The website does not request or store API keys and does not call an external language model.

The LLM adapter builds a prompt from retrieved source chunks and asks the model to answer only from the supplied evidence with chunk IDs in citations. It uses a 45-second timeout and validates that every citation ID exists in the retrieved context. Unknown citations or uncited answers are rejected. Checking citation IDs does not prove claim entailment or factual correctness. The adapter returns the source context alongside the generated answer for human inspection.

Hosted generative mode is a future extension, not an active browser feature. It would require a server-side secret, budget controls, authentication, rate limiting, and separate generation-quality evaluations. Generation cost and generation latency are not included in the lexical benchmark.`},
 {id:'privacy',title:'Vinay Rangabhatla · Privacy & operations',text:`Imported documents and queries stay in browser memory in evidence mode. They are not uploaded to a document storage service. The app stores voluntary anonymous usefulness ratings containing only a random submission ID, rating, retrieval mode, result status, and timestamp. Questions and document text are not included. Workspace content is not persisted. Refreshing the page resets the project workspace. Browser extensions and shared-device access are outside this privacy boundary.

When the optional local LLM adapter is enabled, the question and retrieved source chunks are sent to OpenAI. Only use documents you are permitted to send to that provider. API keys are read from the local process environment and must never be committed to Git. The source bundle excludes local environment files, build output, and dependencies.

The project is a portfolio baseline, not a production service. Production extensions would need access-controlled indexes, tenant isolation, deletion workflows, encrypted storage, monitoring, abuse controls, and a threat model. This project is published as a public website. It exposes only non-sensitive project documentation. Imported personal documents are not shared with other visitors. Anonymous ratings measure perceived usefulness, not independent accuracy.`}
];
export const evalCases: EvalCase[] = [
 {id:'E01',question:'What are the BM25 parameters?',relevantDocuments:['retrieval'],answerable:true},
 {id:'E02',question:'How does reciprocal rank fusion combine rankings?',relevantDocuments:['retrieval'],answerable:true},
 {id:'E03',question:'What does lambda do in maximum marginal relevance?',relevantDocuments:['retrieval'],answerable:true},
 {id:'E04',question:'What is the default chunk size and overlap?',relevantDocuments:['chunking'],answerable:true},
 {id:'E05',question:'Which file formats can ingestion accept?',relevantDocuments:['chunking'],answerable:true},
 {id:'E06',question:'How are source offsets stored?',relevantDocuments:['chunking'],answerable:true},
 {id:'E07',question:'Is query-term coverage a confidence probability?',relevantDocuments:['grounding'],answerable:true},
 {id:'E08',question:'How does evidence mode avoid invented synthesis?',relevantDocuments:['grounding'],answerable:true},
 {id:'E09',question:'What does mean reciprocal rank measure?',relevantDocuments:['evaluation'],answerable:true},
 {id:'E10',question:'Which environment variables does the LLM adapter require?',relevantDocuments:['llm'],answerable:true},
 {id:'E11',question:'What does citation validation check?',relevantDocuments:['llm'],answerable:true},
 {id:'E12',question:'Where do imported documents and queries stay?',relevantDocuments:['privacy'],answerable:true},
 {id:'E13',question:'Who won Wimbledon in 2025?',relevantDocuments:[],answerable:false},
 {id:'E14',question:'What is the price of Bitcoin today?',relevantDocuments:[],answerable:false},
 {id:'E15',question:'Which antibiotic treats pneumonia?',relevantDocuments:[],answerable:false},
 {id:'E16',question:'Who invented the telescope?',relevantDocuments:[],answerable:false},
 {id:'E17',question:'What is the document storage service monthly price?',relevantDocuments:[],answerable:false},
 {id:'E18',question:'What is the generation latency guarantee?',relevantDocuments:[],answerable:false},
 {id:'E19',question:'Which company employs the project owner?',relevantDocuments:[],answerable:false},
 {id:'E20',question:'What is the production accuracy of this system?',relevantDocuments:[],answerable:false}
];
