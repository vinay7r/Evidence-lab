export type FeedbackInput = { id:string; helpful:0|1; mode:'bm25'|'tfidf'|'fusion'; status:'evidence'|'abstained' };
export function validateFeedback(value:unknown): FeedbackInput {
 if (!value || typeof value!=='object' || Array.isArray(value)) throw new Error('Invalid feedback.');
 const v=value as Partial<FeedbackInput>;
 if (Object.keys(v).some(k=>!['id','helpful','mode','status'].includes(k)) || typeof v.id!=='string' || !/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(v.id) || (v.helpful!==0&&v.helpful!==1) || !['bm25','tfidf','fusion'].includes(v.mode??'') || !['evidence','abstained'].includes(v.status??'')) throw new Error('Invalid feedback.');
 return v as FeedbackInput;
}
export const insertFeedbackSql='INSERT INTO feedback (id, helpful, mode, status, created_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT(id) DO NOTHING';
export const feedbackSummarySql='SELECT COUNT(*) AS total, COALESCE(SUM(helpful), 0) AS helpful FROM feedback';
export function parseFeedbackSummary(value:unknown): {total:number;helpful:number} {
 if (!value || typeof value!=='object') throw new Error('Invalid feedback summary.');
 const v=value as {total?:unknown;helpful?:unknown};
 if (typeof v.total!=='number'||typeof v.helpful!=='number'||!Number.isSafeInteger(v.total)||!Number.isSafeInteger(v.helpful)||v.total<0||v.helpful<0||v.helpful>v.total) throw new Error('Invalid feedback summary.');
 return {total:v.total,helpful:v.helpful};
}
export async function readFeedbackBody(request:Request):Promise<string> {
 const reader=request.body?.getReader(); if(!reader)throw new Error('Empty body.'); const decoder=new TextDecoder();let size=0,text='';
 try {while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>1000){await reader.cancel();throw new Error('Body exceeds limit.');}text+=decoder.decode(value,{stream:true});}text+=decoder.decode();return text;}finally{reader.releaseLock();}
}
