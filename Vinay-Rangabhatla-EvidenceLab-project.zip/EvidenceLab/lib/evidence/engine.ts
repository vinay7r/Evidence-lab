/** Dependency-free, inspectable lexical retrieval. Shared by UI, tests and CLI. */
export type DocumentRecord = { id: string; title: string; text: string };
export type Chunk = { id: string; documentId: string; title: string; text: string; start: number; end: number; tokens: string[] };
export type Config = { mode: 'fusion' | 'bm25' | 'tfidf'; topK: number; lambda: number; minCoverage: number; chunkSize: number; overlap: number };
export const defaults: Config = { mode: 'fusion', topK: 3, lambda: 0.8, minCoverage: 0.25, chunkSize: 100, overlap: 20 };
export type Hit = Chunk & { score: number; bm25: number; tfidf: number; bm25Rank: number | null; tfidfRank: number | null; coverage: number };
export type Answer = { question: string; status: 'evidence' | 'abstained'; excerpts: { text: string; chunkId: string; documentId: string; title: string }[]; hits: Hit[]; durationMs: number; chunkCount: number; coverage: number; config: Config };
const stop = new Set('a an the and or of to in is are was were be been being it its for as by at with on from that this these those how what why when which who do does did can could would should i you we they my our their about me tell explain please'.split(' '));
export function tokenize(text: string): string[] { return (text.normalize('NFC').toLowerCase().match(/[\p{L}\p{M}\p{N}]+/gu) ?? []).filter(t => !stop.has(t)); }
export function checkedConfig(input: Partial<Config> = {}): Config {
  const c = { ...defaults, ...input };
  if (!['fusion', 'bm25', 'tfidf'].includes(c.mode) || !Number.isInteger(c.topK) || c.topK < 1 || c.topK > 10 || !Number.isFinite(c.lambda) || c.lambda < 0 || c.lambda > 1 || !Number.isFinite(c.minCoverage) || c.minCoverage < 0 || c.minCoverage > 1 || !Number.isInteger(c.chunkSize) || c.chunkSize < 20 || c.chunkSize > 500 || !Number.isInteger(c.overlap) || c.overlap < 0 || c.overlap >= c.chunkSize) throw new Error('Invalid retrieval configuration.');
  return c;
}
export function chunkDocuments(documents: DocumentRecord[], input: Partial<Config> = {}): Chunk[] {
  const c = checkedConfig(input); const chunks: Chunk[] = []; const ids = new Set<string>();
  for (const doc of documents) {
    if (!doc.id || ids.has(doc.id) || typeof doc.text !== 'string' || typeof doc.title !== 'string') throw new Error('Document IDs must be unique and text/title must be strings.');
    ids.add(doc.id);
    const words = [...doc.text.matchAll(/\S+/g)];
    for (let i = 0, n = 0; i < words.length; i += c.chunkSize - c.overlap, n++) {
      const last = words[Math.min(i + c.chunkSize, words.length) - 1];
      const start = words[i].index!; const end = last.index! + last[0].length;
      const text = doc.text.slice(start, end);
      chunks.push({ id: `${doc.id}:${n}`, documentId: doc.id, title: doc.title, text, start, end, tokens: tokenize(text) });
      if (i + c.chunkSize >= words.length) break;
    }
  }
  return chunks;
}
const counts = (tokens: string[]) => { const m = new Map<string, number>(); for (const t of tokens) m.set(t, (m.get(t) ?? 0) + 1); return m; };
const cosine = (a: Map<string, number>, b: Map<string, number>) => {
  let dot = 0, aa = 0, bb = 0; for (const [t,v] of a) { aa += v*v; dot += v*(b.get(t) ?? 0); } for (const v of b.values()) bb += v*v;
  return aa && bb ? dot / Math.sqrt(aa*bb) : 0;
};
export function answer(question: string, documents: DocumentRecord[], input: Partial<Config> = {}): Answer {
  if (typeof question !== 'string' || !question.trim() || question.length > 2000) throw new Error('Enter a question of 1–2,000 characters.');
  const started = performance.now(); const config = checkedConfig(input); const chunks = chunkDocuments(documents, config); const query = [...new Set(tokenize(question))];
  const df = new Map<string, number>(); for (const chunk of chunks) for (const t of new Set(chunk.tokens)) df.set(t,(df.get(t) ?? 0)+1);
  const idf = (t: string) => Math.log((1 + chunks.length)/(1 + (df.get(t) ?? 0)))+1;
  const vector = (tokens: string[]) => new Map([...counts(tokens)].map(([t,f]) => [t,(1+Math.log(f))*idf(t)]));
  const queryVector = vector(tokenize(question)); const vectors = new Map(chunks.map(c => [c.id,vector(c.tokens)]));
  const avgLength = chunks.reduce((sum,c) => sum+c.tokens.length,0)/(chunks.length || 1);
  const scored: Hit[] = chunks.map(chunk => {
    const freq = counts(chunk.tokens); let bm25 = 0;
    for (const term of query) { const tf = freq.get(term) ?? 0; const ni = df.get(term) ?? 0;
      if (tf) bm25 += Math.log(1+(chunks.length-ni+0.5)/(ni+0.5)) * tf * 2.5/(tf + 1.5*(0.25 + 0.75*chunk.tokens.length/(avgLength || 1)));
    }
    return {...chunk,bm25,tfidf:cosine(queryVector,vectors.get(chunk.id)!),score:0,bm25Rank:null,tfidfRank:null,coverage:query.length ? query.filter(t=>freq.has(t)).length/query.length : 0};
  });
  for (const metric of ['bm25','tfidf'] as const) {
    scored.filter(h=>h[metric]>0).sort((a,b)=>b[metric]-a[metric] || a.id.localeCompare(b.id)).forEach((h,i)=>{ if (metric==='bm25') h.bm25Rank=i+1; else h.tfidfRank=i+1; });
  }
  for (const h of scored) h.score=config.mode==='bm25' ? h.bm25 : config.mode==='tfidf' ? h.tfidf : (h.bm25Rank ? 1/(60+h.bm25Rank):0)+(h.tfidfRank ? 1/(60+h.tfidfRank):0);
  const candidates=scored.filter(h=>h.score>0).sort((a,b)=>b.score-a.score || a.id.localeCompare(b.id)); const max=candidates[0]?.score || 1; const selected: Hit[]=[];
  while (candidates.length && selected.length<config.topK) {
    let best=0,bestScore=-Infinity;
    candidates.forEach((h,i)=>{const similarity=selected.length ? Math.max(...selected.map(s=>cosine(vectors.get(h.id)!,vectors.get(s.id)!))) : 0;
      const mmr=config.lambda*h.score/max-(1-config.lambda)*similarity;
      if (mmr>bestScore) {best=i;bestScore=mmr;}
    }); selected.push(candidates.splice(best,1)[0]);
  }
  const coverage=Math.max(0,...selected.map(h=>h.coverage)); const supported=Boolean(query.length && selected.length && coverage>=config.minCoverage);
  const excerpts: Answer['excerpts']=[]; const seen=new Set<string>();
  if (supported) for (const hit of selected.filter(h=>h.coverage>=config.minCoverage)) {
    // Extract exact source spans. No invented synthesis or inferred claims.
    const sentences=hit.text.match(/[^.!?\n]+(?:[.!?]+|$)/g) ?? [hit.text];
    const ranked=sentences.map((text,index)=>({text:text.trim(),index,overlap:tokenize(text).filter(t=>query.includes(t)).length})).filter(s=>s.overlap>0).sort((a,b)=>b.overlap-a.overlap || a.index-b.index);
    for (const sentence of ranked.slice(0,2)) if (!seen.has(sentence.text.toLowerCase())) { seen.add(sentence.text.toLowerCase()); excerpts.push({text:sentence.text,chunkId:hit.id,documentId:hit.documentId,title:hit.title}); }
  }
  return {question,status:excerpts.length ? 'evidence':'abstained',excerpts,hits:selected,durationMs:performance.now()-started,chunkCount:chunks.length,coverage,config};
}
export type EvalCase = { id: string; question: string; relevantDocuments: string[]; answerable: boolean };
export function evaluate(documents: DocumentRecord[], cases: EvalCase[], input: Partial<Config> = {}) {
  const rows=cases.map(test=>{
    const result=answer(test.question,documents,input); const retrieved=[...new Set(result.hits.map(h=>h.documentId))];
    const rank=retrieved.findIndex(id=>test.relevantDocuments.includes(id));
    const recall=test.relevantDocuments.length ? retrieved.filter(id=>test.relevantDocuments.includes(id)).length/test.relevantDocuments.length : null;
    const dcg=retrieved.reduce((sum,id,i)=>sum+(test.relevantDocuments.includes(id)?1/Math.log2(i+2):0),0);
    const ideal=Array.from({length:Math.min(result.config.topK,test.relevantDocuments.length)},(_,i)=>1/Math.log2(i+2)).reduce((a,b)=>a+b,0);
    return { ...test,retrieved,recall,reciprocalRank:rank<0?0:1/(rank+1),ndcg:ideal?dcg/ideal:null,status:result.status,abstentionCorrect:(result.status==='evidence')===test.answerable,durationMs:result.durationMs };
  });
  const answerable=rows.filter(r=>r.answerable); const unanswerable=rows.filter(r=>!r.answerable);
  const mean=(values:number[])=>values.length?values.reduce((a,b)=>a+b,0)/values.length:0;
  const latencies=rows.map(r=>r.durationMs).sort((a,b)=>a-b);
  return {config:checkedConfig(input),rows,metrics:{recall:mean(answerable.map(r=>r.recall??0)),mrr:mean(answerable.map(r=>r.reciprocalRank)),ndcg:mean(answerable.map(r=>r.ndcg??0)),abstentionAccuracy:mean(unanswerable.map(r=>Number(r.abstentionCorrect))),decisionAccuracy:mean(rows.map(r=>Number(r.abstentionCorrect))),p95Ms:latencies[Math.max(0,Math.ceil(latencies.length*0.95)-1)]??0},caseCount:rows.length};
}
