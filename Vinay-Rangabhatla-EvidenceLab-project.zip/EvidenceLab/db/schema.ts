import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const feedback = sqliteTable('feedback', {
 id: text('id').primaryKey(),
 helpful: integer('helpful').notNull(),
 mode: text('mode').notNull(),
 status: text('status').notNull(),
 createdAt: integer('created_at').notNull(),
});
