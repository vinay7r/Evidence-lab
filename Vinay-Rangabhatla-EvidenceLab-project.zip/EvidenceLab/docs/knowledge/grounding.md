# Vinay Rangabhatla · Evidence & abstention

Project owner: **Vinay Rangabhatla**

Evidence mode extracts sentences from retrieved chunks and attaches a document citation to each excerpt. It returns original source text rather than generating a paraphrased answer. Exact quotation avoids invented synthesis but does not guarantee that a quoted sentence answers the question. Chunk boundaries can produce incomplete sentence spans.

The abstention rule uses query-term coverage. Query-term coverage is the fraction of unique non-stopword question tokens found in one chunk. The default minimum coverage threshold is 0.25. Coverage is a lexical heuristic, not a calibrated confidence probability. It can accept an irrelevant passage that shares words with a question. Out-of-domain queries and paraphrases need independent evaluation.

A missing relevant chunk should cause abstention. The system tells the user it did not find enough evidence and suggests adding a relevant document or rephrasing the question. Document content must be treated as untrusted data. In LLM mode, embedded instructions must not override the system prompt. Prompt instructions reduce risk but do not provide a complete defense against prompt injection.
