# Vinay Rangabhatla · Privacy & operations

Project owner: **Vinay Rangabhatla**

Imported documents and queries stay in browser memory in evidence mode. They are not uploaded to a document storage service. The app stores voluntary anonymous usefulness ratings containing only a random submission ID, rating, retrieval mode, result status, and timestamp. Questions and document text are not included. Workspace content is not persisted. Refreshing the page resets the project workspace. Browser extensions and shared-device access are outside this privacy boundary.

When the optional local LLM adapter is enabled, the question and retrieved source chunks are sent to OpenAI. Only use documents you are permitted to send to that provider. API keys are read from the local process environment and must never be committed to Git. The source bundle excludes local environment files, build output, and dependencies.

The project is a portfolio baseline, not a production service. Production extensions would need access-controlled indexes, tenant isolation, deletion workflows, encrypted storage, monitoring, abuse controls, and a threat model. This project is published as a public website. It exposes only non-sensitive project documentation. Imported personal documents are not shared with other visitors. Anonymous ratings measure perceived usefulness, not independent accuracy.
