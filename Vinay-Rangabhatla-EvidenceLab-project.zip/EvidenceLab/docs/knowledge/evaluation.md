# Vinay Rangabhatla · Evaluation protocol

Project owner: **Vinay Rangabhatla**

The bundled evaluation suite contains 20 labeled cases: 12 answerable questions and 8 unanswerable questions. These questions exercise the actual EvidenceLab project documentation owned by Vinay Rangabhatla. The suite is a development benchmark, not a held-out test set. Results from this suite do not establish real-world accuracy. Relevance labels are at document level. Deduplicated retrieved document IDs determine retrieval metrics.

Recall at K measures the proportion of relevant documents retrieved among the top K selected chunks. Mean reciprocal rank measures the inverse rank of the first relevant document, averaged over answerable cases. Normalized discounted cumulative gain measures rank quality with binary relevance labels. Abstention accuracy measures correct refusal on unanswerable cases. Decision accuracy evaluates acceptance or refusal across all cases.

The dashboard compares BM25, TF-IDF, and rank fusion under the same chunking, top K, and diversity settings. Evaluation runs synchronously on the device. P95 latency is measured with performance.now and varies by device and current load. It excludes file reading, network requests, and LLM generation. A production benchmark needs a frozen test set, a separate tuning set, and more difficult distractor passages.
