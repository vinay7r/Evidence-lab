# Vinay Rangabhatla · Retrieval design

Project owner: **Vinay Rangabhatla**

EvidenceLab uses two lexical retrievers: BM25 and TF-IDF cosine similarity. BM25 uses term-frequency saturation and document-length normalization with k1 = 1.5 and b = 0.75. TF-IDF uses log-scaled term frequency and smoothed inverse document frequency. Neither lexical retriever understands synonyms or semantic meaning. A question using different vocabulary may retrieve weak evidence or no evidence.

Reciprocal rank fusion combines the BM25 and TF-IDF rankings using the sum of 1 / (60 + rank). Fusion compares ranks instead of incompatible raw scores. A chunk with no matching query terms is excluded from both rankings. Fusion is a baseline combination of two lexical signals, not dense hybrid search.

Maximum marginal relevance reranks candidate chunks to balance query relevance and novelty. The relevance weight lambda defaults to 0.8. Higher lambda favors relevance. Lower lambda penalizes chunks similar to already selected chunks. EvidenceLab measures chunk similarity with TF-IDF cosine similarity. The maximum number of returned chunks is controlled by top K.
