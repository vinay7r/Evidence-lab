# Vinay Rangabhatla · Ingestion specification

Project owner: **Vinay Rangabhatla**

The ingestion pipeline accepts UTF-8 plain text and Markdown documents. The app does not parse PDF, images, spreadsheets, or HTML. Each imported file may contain at most 200 KB and the workspace permits at most 20 documents. Imported documents live in browser memory and disappear when the page is refreshed.

Documents are split into overlapping word windows. The default chunk size is 100 whitespace-separated words with an overlap of 20 words. Overlap helps retain context near a chunk boundary but increases index size and creates duplicate evidence. Every chunk keeps its document ID, chunk ID, title, start character offset, and end character offset. These offsets locate the exact original source span.

Longer chunks provide more context but may dilute relevance and increase prompt cost. Shorter chunks improve passage precision but can separate a claim from its qualifications. A production extension would compare sentence-aware and structure-aware segmentation using held-out relevance judgments.
