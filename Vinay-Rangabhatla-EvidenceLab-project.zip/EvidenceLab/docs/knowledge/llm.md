# Vinay Rangabhatla · LLM integration

Project owner: **Vinay Rangabhatla**

The optional local command-line integration uses the OpenAI Responses API. It requires an OPENAI_API_KEY environment variable and an OPENAI_MODEL environment variable. No key is required for browser evidence mode. The website does not request or store API keys and does not call an external language model.

The LLM adapter builds a prompt from retrieved source chunks and asks the model to answer only from the supplied evidence with chunk IDs in citations. It uses a 45-second timeout and validates that every citation ID exists in the retrieved context. Unknown citations or uncited answers are rejected. Checking citation IDs does not prove claim entailment or factual correctness. The adapter returns the source context alongside the generated answer for human inspection.

Hosted generative mode is a future extension, not an active browser feature. It would require a server-side secret, budget controls, authentication, rate limiting, and separate generation-quality evaluations. Generation cost and generation latency are not included in the lexical benchmark.
