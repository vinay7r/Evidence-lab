# EvidenceLab — experiment record

Project owner: **Vinay Rangabhatla**

## Run and reproduce

```bash
node --test tests/*.test.mjs
node scripts/evidence/evaluate.mjs
```

Inspect the machine-readable metrics, every case, relevant document IDs, retrieved IDs, and decisions in `evaluation-results.json`. The file records generation time and the exact configuration. UI evaluation reruns all three methods using the chosen top K, relevance weight, and threshold while preserving the original project corpus.

## Baselines and ablation

| Comparison | Question it answers |
| --- | --- |
| BM25 vs TF-IDF | Does term saturation and length normalization help this corpus? |
| Rank fusion vs either baseline | Does combining rankings improve robustness? |
| Lambda 1 vs 0.8 vs 0.4 | Does diversity help evidence coverage or harm relevance? |
| Top K 1 vs 3 vs 5 | How much retrieval coverage costs additional context? |
| Coverage 0.25 vs 0.5 vs 0.75 | What is the acceptance/refusal tradeoff? |
| Chunk size 50 vs 100 vs 200 | Do smaller passages improve precision at a boundary? |

These are proposed comparisons; only the default three-method run is saved initially. Do not report unrun comparisons as findings.

## Interpreting failures

Unanswerable questions about document-storage prices and generation-latency guarantees share terms with implementation notes. A lexical gate can accept them even though no answer exists. The question about production accuracy can retrieve a limitation statement; that statement is useful evidence but is not a numerical accuracy answer. The current binary answerability labels mark it unanswerable to expose this ambiguity. Human evaluation should distinguish informative refusal context from an actual answer.

A term-matching result is not a semantic answer. The dashboard displays failures instead of filtering them away. Its displayed results are calculated at runtime, not hard-coded marketing metrics.

## Validation boundaries

Core and adapter tests execute locally. Provider responses are mocked, so they verify request construction and validation rather than live model quality. No live API call was made without a supplied key. Browser WebMCP validation and visual QA are environment-dependent and are recorded separately in `verification.md`.

## Next study

Create separate tuning and held-out sets using real, permissioned documents. Include paraphrases, near-duplicate distractors, source conflicts, unsupported premises, and adversarial instructions. Compare dense retrieval and reranking against the lexical baselines. Add evidence entailment judgments and human-scored generated answers. Freeze thresholds before measuring the held-out set.
