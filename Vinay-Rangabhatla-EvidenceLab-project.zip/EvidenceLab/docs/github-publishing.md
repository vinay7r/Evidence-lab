# EvidenceLab — GitHub publishing

Project owner: **Vinay Rangabhatla**

Suggested repository name: `evidence-lab`  
Suggested description: Evidence-first AI document assistant with inspectable retrieval, citations, evaluation, and optional grounded generation.  
Suggested topics: `information-retrieval`, `rag`, `ai-evaluation`, `bm25`, `typescript`, `react`.

GitHub account access and the intended username must be verified before publishing. The source repository used for the hosted app is separate from the owner's personal GitHub repository. No personal GitHub push is claimed until it succeeds.

The downloadable archive omits keys, local state, build output, and dependencies. Initialize it as a clean repository, run the checks, and publish to the verified account. Keep the app's hosting identity out of another owner's deployment.

Add the repository URL and a publicly accessible project URL to the LinkedIn project entry once available. Pinning the repository to the profile makes it easier for recruiters to inspect.
