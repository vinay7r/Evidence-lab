# EvidenceLab — LinkedIn project entry

**Vinay Rangabhatla**  
Profile: https://www.linkedin.com/in/vinay-rangabhatla-995847295

## Project title

EvidenceLab — Document Search & AI Evaluation

## Description

EvidenceLab is my project exploring how document-grounded AI can make its sources and decisions easier to inspect.

It combines BM25 and TF-IDF search, reciprocal rank fusion, and diversity reranking to retrieve relevant passages with source citations. Visitors can try their own text documents, compare retrieval methods, run the evaluation suite, and share feedback.

I focused on transparency: showing both successful results and failure cases, keeping visitor usefulness ratings separate from benchmark metrics, and documenting the system’s limitations. The project also includes an optional local LLM integration, automated tests, and technical notes.

## Skills

Information Retrieval · Natural Language Processing · Retrieval-Augmented Generation · TypeScript · React · AI Evaluation

## Website

https://evidence-lab.goodaspen8.chatgpt.site
