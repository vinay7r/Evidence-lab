# EvidenceLab — interview guide

Project owner: **Vinay Rangabhatla**

## Two-minute walkthrough

“I worked on EvidenceLab, an evidence-first document question-answering foundation. Its browser workspace returns exact source excerpts and shows the retrieval trace. I compare BM25, TF-IDF, and reciprocal rank fusion, then use maximum marginal relevance to control duplicate evidence. A separate optional LLM adapter generates from the selected context. The evaluation separates document retrieval from refusal behavior and deliberately shows failures.”

Use the live app to demonstrate one successful retrieval and one refusal failure, then explain the relevant code and tradeoffs.

## Questions to prepare

**Why BM25?** It rewards matching terms with saturation and adjusts for passage length. It is cheap, inspectable, and a useful baseline. It does not infer semantic similarity.

**Why two lexical retrievers?** This is a controlled comparison of different term-weighting signals. Fusion is not automatically an improvement. A broader benchmark is needed to decide whether to keep it.

**Why fuse ranks rather than scores?** BM25 and cosine similarity have different scales. RRF combines ordering without relying on raw-score calibration.

**What does MMR change?** It trades query relevance against redundancy. Lower lambda promotes different passages but can choose weaker evidence. Demonstrate the existing diversity test.

**Is coverage confidence?** No. It measures lexical overlap. Similar words can appear in irrelevant passages. Explain a failing unanswerable case in the dashboard.

**Do citations prove accuracy?** No. Exact excerpts prove what text was returned and where it came from. Citation-ID validation only checks the reference exists. Claim entailment requires additional judgment.

**What is measured?** Document recall, first-relevant rank, binary rank quality, refusal decisions, and device-local retrieval latency. Model-answer quality is not measured by these metrics.

**How do imports preserve privacy?** Browser documents remain in memory. The local LLM CLI sends the question and selected chunks to OpenAI only when explicitly enabled. No key is entered into the browser.

**How would you scale this?** Cache indexes, move work off the main thread, shortlist candidates, and introduce a permission-aware backend. Add isolation, deletion, quotas, and monitoring before production use.

**What would you improve first?** Separate tuning and held-out evaluation, then dense retrieval and a calibrated refusal classifier. Prove the improvement against baselines rather than assuming more components improve quality.

## Learn by modifying

1. Read `answer()` and derive the BM25 and RRF formulas on paper.
2. Change lambda and explain why the selected chunks change.
3. Add one paragraph and one relevance judgment to the project corpus.
4. Add a difficult unanswerable question and explain its outcome.
5. Implement a cached index and measure before/after latency.
6. Run the optional LLM adapter with a permitted document and inspect its citations manually.

## Keep the explanation precise

The current system uses lexical retrieval and an optional LLM adapter. Be ready to explain how that differs from training a model or using dense embeddings. Discuss the measured results, known limitations, and changes you have tested.
