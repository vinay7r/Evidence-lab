# EvidenceLab — architecture

Project owner: **Vinay Rangabhatla**  
Profile: https://www.linkedin.com/in/vinay-rangabhatla-995847295

## Problem and behavior

A search system can return plausible evidence without answering the question. EvidenceLab exposes that distinction: users see exact source text, citations, query-term coverage, ranking signals, and measured failures instead of an unexplained answer.

## Processing flow

```mermaid
flowchart TD
  A[Project documents or imported text] --> B[Overlapping chunks and source spans]
  Q[Question tokens] --> C[BM25 and TF-IDF]
  B --> C
  C --> D[Rank fusion and MMR]
  D --> E{Coverage gate}
  E -->|Pass| F[Cited source excerpts]
  E -->|Fail| G[Abstention]
  D --> H[Optional local LLM adapter]
  H --> I[Citation validation and generated answer]
```

The local CLI adapter runs only after the retrieval stage accepts the result. In the browser, source files and questions never leave the current page's memory. Voluntary usefulness feedback sends only a random UUID, binary rating, retrieval mode, and result status to a prepared-statement D1 endpoint. Its database also records a timestamp. Repeated submission of the same UUID is idempotent. No visitor identity, IP address, question, document name, or source text is stored. These ratings are unverified and can be influenced by repeat visitors; they are not a scientific accuracy benchmark. `lib/evidence/engine.ts` is the common engine, preventing UI and evaluation code from implementing different retrieval algorithms.

## Algorithm decisions

BM25 uses `k1 = 1.5` and `b = 0.75`. It saturates repeated terms and normalizes passage length. TF-IDF uses `(1 + log(tf)) × (log((N + 1)/(df + 1)) + 1)` and cosine similarity. These are both lexical methods. Calling the combination dense hybrid retrieval would be inaccurate.

RRF adds `1/(60 + rank)` for each nonzero ranking. It avoids adding incomparable raw scores. The fusion constant is a conventional fixed baseline, not a parameter tuned to this corpus. The dashboard exposes the original ranks and scores.

MMR greedily selects `lambda × normalized relevance − (1 − lambda) × maximum cosine similarity to already selected chunks`. At lambda 1, relevance dominates; at lower values, novelty matters more. Diversity can remove duplicate chunks but can also reduce ranking quality.

Chunk IDs are document ID plus chunk index. Offsets refer to original JavaScript UTF-16 character positions, not bytes or Unicode codepoint indices. NFC-normalized tokens preserve Unicode combining marks. English stopwords are removed; there is no language-specific stemming or multilingual semantic understanding.

## Evidence and refusal

Coverage is the fraction of distinct non-stopword question tokens present in a chunk. The default threshold is 0.25. This is deliberately simple and inspectable; it is not a calibrated probability. Coverage is computed at chunk level, while excerpts are selected by sentence token overlap. Therefore, a chunk can pass even if the returned sentence does not answer the question.

The engine returns exact substrings, deduplicates excerpt text, and records chunk citations. It does not generate paraphrases. A chunk boundary may yield an incomplete sentence. The optional LLM path requests a JSON answer with source IDs, rejects missing/unknown/inconsistent citations, and exposes context for inspection. These checks do not establish claim correctness or defeat all prompt injections.

## Evaluation protocol

The corpus is the actual EvidenceLab technical documentation. Labels are at document level. The engine selects top K chunks, then deduplicates document IDs before computing rank metrics. Recall@K therefore means document recall within those selected chunks. MRR and binary nDCG use the deduplicated order. The development set contains 12 answerable and 8 unanswerable questions, including lexical distractors.

P95 is the nearest-rank 95th percentile of per-question timing. It includes chunking, scoring, reranking, and extraction. It excludes file reads, network time, and generation. This small development corpus cannot support generalization claims.

## Complexity and scale

The engine rebuilds its index on each query for transparency and simplicity. Scoring is roughly linear in total token volume plus vocabulary, and MMR reranks all matching chunks, with up to K comparisons per candidate. The import limits bound browser work, but this architecture is intended for small corpora. A scalable extension would cache an immutable index, use a Web Worker, shortlist candidates before MMR, and use access-controlled indexes in a backend.

## Production extension

A hosted generative service needs server-held secrets, authentication, request validation, per-user quotas, timeouts, budget controls, source access filtering, deletion, and monitoring. Tenant authorization must happen before retrieval. Embedding vectors do not replace permissions. A separate evaluation should test generated claims, adversarial documents, stale sources, and explicit refusals.
