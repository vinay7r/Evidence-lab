# EvidenceLab — project report

**Project owner: Vinay Rangabhatla**  
**Category:** AI engineering / information retrieval / grounded question answering  
**Version:** 1.0  
**LinkedIn:** https://www.linkedin.com/in/vinay-rangabhatla-995847295

## Objective

Build a complete, inspectable foundation for document-grounded AI applications. The project helps a reader understand why evidence was retrieved, trace an excerpt to its source, reproduce retrieval metrics, and see refusal failures.

## Delivered system

A responsive React workbench contains a document library, question interface, retrieval settings, evidence excerpts, source reader, trace panel, evaluation dashboard, and engineering notes. The library starts with Vinay Rangabhatla's actual EvidenceLab project documents; users can add their own UTF-8 text or Markdown. Each result can be exported as JSON. The website is public, and voluntary usefulness ratings persist in a database without storing questions or document text. Visitor ratings are unverified and separate from benchmark accuracy.

The TypeScript core implements chunking with character offsets, BM25, TF-IDF cosine similarity, reciprocal rank fusion, maximum marginal relevance, source extraction, and a lexical refusal rule. The same code powers CLI queries and evaluation. The optional local LLM integration uses OpenAI's Responses API and verifies source IDs in returned JSON. Automated tests cover retrieval behavior, data integrity, ranking diversity, metric definitions, invalid input, and mocked provider responses.

## Methodology

First establish two lexical baselines. Combine their rankings without mixing raw score scales. Rerank for evidence diversity. Retain exact spans for provenance. Evaluate retrieval and refusal separately. Expose each stage instead of presenting a single unexplained confidence value.

The evaluation set was authored from the actual project corpus during development. It is intentionally transparent and includes failures. It has not been independently labeled or held out. Numerical results are in `evaluation-results.json` and can be reproduced using the evaluation script.

## Findings

The answerable development cases are generally easy to retrieve because they share vocabulary with the project documents. The difficult unanswerable cases expose the main weakness: word overlap does not establish answerability. A production version would need held-out evaluation and a more carefully calibrated evidence gate. Fusion should be kept only if broader experiments show benefits beyond the baselines.

## Knowledge demonstrated

Information retrieval formulas, rank fusion, reranking tradeoffs, chunk provenance, evaluation denominators, ablation comparisons, input validation, privacy boundaries, provider integration, and reproducible engineering practices. This project does not claim model training, semantic embeddings, real-world accuracy, or enterprise readiness.

## Project notes

EvidenceLab is my project for exploring document retrieval, grounded answers, and evaluation. The accompanying notes explain the design decisions and the experiments I can run next.
