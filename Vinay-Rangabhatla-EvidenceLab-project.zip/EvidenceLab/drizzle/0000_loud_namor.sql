CREATE TABLE `feedback` (
	`id` text PRIMARY KEY NOT NULL,
	`helpful` integer NOT NULL,
	`mode` text NOT NULL,
	`status` text NOT NULL,
	`created_at` integer NOT NULL
);
